# 🧹 THE CLEANERS — MVP v0.1

> **Horror co-op cleaning game** | Godot 4.2+ | 1-4 jugadores

---

## 🎮 Concepto

Eres parte de una empresa clandestina de limpieza. Cuando hay un crimen, te llaman. Tienes que limpiar toda la evidencia antes de que llegue la policía.

---

## ⚡ Requisitos

- **Godot 4.2** o superior (descarga en https://godotengine.org/download)
- Sistema: Windows / macOS / Linux
- No se necesitan assets externos — todo se genera por código

---

## 🚀 Cómo Ejecutar

### Opción 1: Godot Editor
1. Abre Godot 4
2. Clic en **"Import"** o **"Scan"**
3. Selecciona la carpeta `the_cleaners/`
4. Se abre el editor — presiona **F5** para jugar, o el botón ▶️

### Opción 2: Exportar (opcional)
1. Project → Export
2. Selecciona plataforma
3. Exporta y distribuye

---

## 🗂️ Estructura del Proyecto

```
the_cleaners/
├── project.godot              ← Configuración del proyecto
├── scenes/
│   ├── ui/
│   │   ├── main_menu.tscn     ← Menú principal + selector de roles
│   │   └── results.tscn       ← Pantalla de resultados con calificación
│   ├── safehouse/
│   │   └── safehouse.tscn     ← Safehouse inicial, espera la llamada
│   └── crime_scene/
│       └── crime_scene.tscn   ← ESCENA PRINCIPAL — nivel de juego completo
├── scripts/
│   ├── systems/
│   │   ├── GameManager.gd     ← [AUTOLOAD] Estado global, timer, objetivos
│   │   └── ObjectiveSystem.gd ← [AUTOLOAD] Gestión de objetivos
│   ├── player/
│   │   └── PlayerController.gd ← FPS controller completo con roles
│   ├── entities/
│   │   ├── Evidence.gd        ← Clase base para toda la evidencia
│   │   ├── Door.gd            ← Sistema de puertas con colisión
│   │   └── Phone.gd           ← Teléfono interactivo (safehouse)
│   ├── crime_scene/
│   │   ├── CrimeSceneManager.gd ← Manager de la escena principal
│   │   └── LevelBuilder.gd    ← Construye la casa + evidencia proceduralmente
│   └── ui/
│       ├── MainMenu.gd        ← Lógica del menú + selector de rol
│       ├── HUD.gd             ← HUD completo (timer, objetivos, ruido, etc.)
│       ├── Results.gd         ← Pantalla de resultados
│       └── PauseMenu.gd       ← Menú de pausa
└── assets/
    ├── audio/                 ← (Agrega aquí tus .wav/.ogg)
    ├── materials/             ← (Texturas futuras)
    └── fonts/                 ← (Fuentes futuras)
```

---

## 🎯 Flujo de Juego (MVP)

```
Menú Principal
    ↓ Elegir rol
Safehouse
    ↓ Suena el teléfono (~8 segundos)
    ↓ [E] Contestar → Briefing de misión
    ↓ Caminar hasta la Van (marcada en verde)
Crime Scene
    ↓ TIMER INICIA (5 minutos)
    ↓ Limpiar sangre (x5) — mantén [E]
    ↓ Hackear cámaras (x2) — mantén [E]
    ↓ Recoger arma (x1) — [E]
    ↓ Destruir documentos (x3) — mantén [E]
    ↓ Mover cuerpo (x1) — [E] para cargar, [G] para soltar
    ↓ Ir a la zona de salida (verde)
Pantalla de Resultados (calificación S/A/B/C/D)
```

---

## 🕹️ Controles

| Tecla | Acción |
|-------|--------|
| WASD | Mover |
| Mouse | Mirar |
| E | Interactuar / Limpiar (mantener) |
| Shift | Sprint |
| Ctrl | Agacharse |
| G | Soltar objeto cargado |
| R | Radio (futuro) |
| Esc | Pausa |

---

## 👥 Roles

| Rol | Bonificación |
|-----|-------------|
| **Limpiador** | Limpia sangre 2x más rápido |
| **Hacker** | Borra cámaras, más silencioso |
| **Cargador** | Mueve cuerpos, doble capacidad de carga |
| **Vigilante** | Más rápido, mucho más silencioso |

---

## 📋 Objetivos de la Misión

| Objetivo | Cantidad | Quién lo hace mejor |
|----------|----------|---------------------|
| Limpiar manchas de sangre | 5 | Limpiador |
| Borrar cámaras | 2 | Hacker |
| Recoger armas | 1 | Cualquiera |
| Destruir documentos | 3 | Cualquiera |
| Mover el cuerpo | 1 | Cargador |

---

## 🏆 Sistema de Calificación

| Calificación | Condición |
|--------------|-----------|
| **S** | Completado en <40% del tiempo + ruido bajo |
| **A** | Completado en <60% del tiempo |
| **B** | Completado en <80% del tiempo |
| **C** | Completado antes de que llegue la policía |
| **D** | No se completaron todos los objetivos |

---

## 🔧 Configuración de Autoloads (Importante)

En el Editor de Godot, ve a:
**Project → Project Settings → Autoload**

Agrega:
- `GameManager` → `res://scripts/systems/GameManager.gd`
- `ObjectiveSystem` → `res://scripts/systems/ObjectiveSystem.gd`

*(El project.godot ya los incluye, pero verifica que estén activos)*

---

## 🛠️ Próximos Pasos (Post-MVP)

- [ ] Texturas reales (pisos, paredes, muebles)
- [ ] Sonidos (pasos, limpieza, puertas, respiración)
- [ ] Sirenas de policía + efectos de luz roja/azul
- [ ] Safehouse completamente construida con muebles
- [ ] Multiplayer (GodotSteam o red local)
- [ ] Más misiones / mapas
- [ ] Sistema de inventario de herramientas
- [ ] IA de policías que patrullan
- [ ] Efectos de partículas para limpieza
- [ ] Menú de selección de misiones

---

## 🐛 Troubleshooting

**El juego no inicia:**
- Verifica que usas Godot 4.2+
- Confirma que los Autoloads están configurados

**El player cae al vacío:**
- El LevelBuilder construye los pisos al inicio — espera 1-2 frames
- Si persiste, revisa que `LevelBuilder.gd` está adjunto al nodo `LevelBuilder`

**No aparece la evidencia:**
- El `LevelBuilder` crea la evidencia en `_ready()`. Verifica que el script está en el nodo

**Las puertas no funcionan:**
- Asegúrate que los colliders de los jugadores están en `collision_layer = 2`
- Las puertas usan `collision_mask = 1` para detección

---

*THE CLEANERS — "Limpia el crimen. No dejes rastros."*
