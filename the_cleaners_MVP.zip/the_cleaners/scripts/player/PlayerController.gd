extends CharacterBody3D

# THE CLEANERS - FPS Player Controller
# Handles movement, camera, interaction, and role-based abilities

signal interactable_found(node: Node, label: String)
signal interactable_lost()
signal item_picked_up(item_name: String)
signal item_dropped()
signal role_ability_used()

# Movement settings
const WALK_SPEED = 3.5
const SPRINT_SPEED = 5.5
const CROUCH_SPEED = 1.8
const JUMP_VELOCITY = 0.0  # No jumping - realistic
const MOUSE_SENSITIVITY = 0.002
const GRAVITY = 9.8

# Carrying settings
const CARRY_DISTANCE = 1.8
const INTERACT_DISTANCE = 2.2
const MAX_CARRY_WEIGHT = 80.0  # kg

# Bob settings
const BOB_FREQ = 2.0
const BOB_AMP = 0.03

# Node references
@onready var camera: Camera3D = $Head/Camera3D
@onready var head: Node3D = $Head
@onready var interact_ray: RayCast3D = $Head/Camera3D/InteractRay
@onready var carry_point: Node3D = $Head/Camera3D/CarryPoint
@onready var footstep_timer: Timer = $FootstepTimer
@onready var breathing_player: AudioStreamPlayer3D = $BreathingPlayer
@onready var footstep_player: AudioStreamPlayer3D = $FootstepPlayer
@onready var interact_sound: AudioStreamPlayer3D = $InteractSound
@onready var crouch_shape: CollisionShape3D = $CrouchShape
@onready var stand_shape: CollisionShape3D = $StandShape

# State
var current_speed: float = WALK_SPEED
var is_crouching: bool = false
var is_sprinting: bool = false
var is_carrying: bool = false
var carried_object: RigidBody3D = null
var carried_weight: float = 0.0
var current_interactable: Node = null
var bob_time: float = 0.0
var original_head_y: float = 0.0
var stamina: float = 100.0
var noise_emitted: float = 0.0

# Role
var player_role: GameManager.PlayerRole = GameManager.PlayerRole.CLEANER
var role_speed_modifier: float = 1.0
var role_noise_modifier: float = 1.0
var role_carry_modifier: float = 1.0
var role_clean_modifier: float = 1.0

func _ready():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	original_head_y = head.position.y
	
	# Apply role if GameManager exists
	if has_node("/root/GameManager"):
		player_role = GameManager.get_role_for_player(self)
		_apply_role_modifiers()
	
	print("[Player] Ready. Role: ", GameManager.PlayerRole.keys()[player_role])

func _apply_role_modifiers():
	match player_role:
		GameManager.PlayerRole.CLEANER:
			role_clean_modifier = 2.0     # 2x faster cleaning
			role_noise_modifier = 0.9
		GameManager.PlayerRole.HACKER:
			role_speed_modifier = 1.0
			role_noise_modifier = 0.8     # Quieter
		GameManager.PlayerRole.CARRIER:
			role_carry_modifier = 2.0     # Can carry more weight
			role_speed_modifier = 0.9
		GameManager.PlayerRole.LOOKOUT:
			role_speed_modifier = 1.15    # Faster
			role_noise_modifier = 0.6     # Much quieter

func _physics_process(delta: float):
	_handle_gravity(delta)
	_handle_movement(delta)
	_handle_crouch(delta)
	_handle_head_bob(delta)
	_update_carry_object()
	_check_interaction()
	
	move_and_slide()

func _handle_gravity(delta: float):
	if not is_on_floor():
		velocity.y -= GRAVITY * delta

func _handle_movement(delta: float):
	var input_dir = Vector2.ZERO
	if Input.is_action_pressed("move_forward"):
		input_dir.y -= 1
	if Input.is_action_pressed("move_backward"):
		input_dir.y += 1
	if Input.is_action_pressed("move_left"):
		input_dir.x -= 1
	if Input.is_action_pressed("move_right"):
		input_dir.x += 1
	
	input_dir = input_dir.normalized()
	
	# Sprint
	is_sprinting = Input.is_action_pressed("sprint") and not is_crouching and not is_carrying
	if is_sprinting and stamina > 0:
		current_speed = SPRINT_SPEED * role_speed_modifier
		stamina = max(0, stamina - 20 * delta)
	elif is_crouching:
		current_speed = CROUCH_SPEED * role_speed_modifier
	else:
		current_speed = WALK_SPEED * role_speed_modifier
		stamina = min(100, stamina + 10 * delta)
	
	# Apply carry weight penalty
	if is_carrying:
		var weight_factor = 1.0 - (carried_weight / MAX_CARRY_WEIGHT / role_carry_modifier) * 0.5
		current_speed *= weight_factor
	
	var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
		_emit_noise(delta)
	else:
		velocity.x = move_toward(velocity.x, 0, current_speed)
		velocity.z = move_toward(velocity.z, 0, current_speed)

func _handle_crouch(delta: float):
	var want_crouch = Input.is_action_pressed("crouch")
	if want_crouch != is_crouching:
		is_crouching = want_crouch
		stand_shape.disabled = is_crouching
		crouch_shape.disabled = not is_crouching
		
		var target_y = original_head_y - 0.5 if is_crouching else original_head_y
		head.position.y = lerp(head.position.y, target_y, 10.0 * delta)

func _handle_head_bob(delta: float):
	var moving = velocity.length() > 0.5 and is_on_floor()
	if moving:
		bob_time += delta * current_speed * (1.5 if is_sprinting else 1.0)
		head.position.y = original_head_y + sin(bob_time * BOB_FREQ) * BOB_AMP
		if is_crouching:
			head.position.y -= 0.5
	else:
		head.position.y = lerp(head.position.y, original_head_y - (0.5 if is_crouching else 0.0), 5.0 * delta)

func _emit_noise(delta: float):
	var noise = 0.0
	if is_sprinting:
		noise = 15.0 * delta
	elif is_crouching:
		noise = 1.0 * delta
	else:
		noise = 5.0 * delta
	
	noise *= role_noise_modifier
	if is_carrying:
		noise *= 1.3
	
	GameManager.add_noise(noise)

func _update_carry_object():
	if is_carrying and carried_object:
		var target = carry_point.global_position
		var carry_force = (target - carried_object.global_position) * 20.0
		carried_object.linear_velocity = carry_force
		carried_object.angular_velocity = Vector3.ZERO

func _check_interaction():
	if interact_ray.is_colliding():
		var collider = interact_ray.get_collider()
		if collider and collider.has_method("get_interact_label"):
			if current_interactable != collider:
				current_interactable = collider
				emit_signal("interactable_found", collider, collider.get_interact_label())
		else:
			_clear_interactable()
	else:
		_clear_interactable()

func _clear_interactable():
	if current_interactable:
		current_interactable = null
		emit_signal("interactable_lost")

func _input(event: InputEvent):
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * MOUSE_SENSITIVITY)
		head.rotate_x(-event.relative.y * MOUSE_SENSITIVITY)
		head.rotation.x = clamp(head.rotation.x, -PI/2.2, PI/2.2)
	
	if event.is_action_pressed("interact"):
		_try_interact()
	
	if event.is_action_pressed("drop_item"):
		_try_drop()
	
	if event.is_action_pressed("pause"):
		_toggle_pause()

func _try_interact():
	if current_interactable:
		if current_interactable.has_method("interact"):
			current_interactable.interact(self)
			print("[Player] Interacted with: ", current_interactable.name)

func _try_drop():
	if is_carrying and carried_object:
		_drop_carried_object()

func pick_up_object(obj: RigidBody3D, weight: float = 10.0):
	if weight > MAX_CARRY_WEIGHT * role_carry_modifier:
		print("[Player] Object too heavy!")
		# Show message - implement via signal
		return false
	
	carried_object = obj
	carried_weight = weight
	is_carrying = true
	
	obj.freeze = false
	obj.gravity_scale = 0.0
	obj.collision_layer = 0
	obj.collision_mask = 0
	
	emit_signal("item_picked_up", obj.name)
	return true

func _drop_carried_object():
	if carried_object:
		carried_object.gravity_scale = 1.0
		carried_object.collision_layer = 1
		carried_object.collision_mask = 1
		carried_object.linear_velocity = Vector3.ZERO
		carried_object = null
		carried_weight = 0.0
		is_carrying = false
		emit_signal("item_dropped")

func _toggle_pause():
	get_tree().paused = !get_tree().paused
	if get_tree().paused:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	else:
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func get_role_label() -> String:
	return GameManager.PlayerRole.keys()[player_role]

func get_clean_speed() -> float:
	return role_clean_modifier
