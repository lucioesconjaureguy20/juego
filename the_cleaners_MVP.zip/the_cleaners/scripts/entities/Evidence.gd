extends Node3D

# THE CLEANERS - Evidence Base Class
# All interactable evidence inherits from this

class_name Evidence

signal evidence_cleaned(evidence: Evidence)
signal cleaning_progress(percent: float)

enum EvidenceType {
	BLOOD_STAIN,
	CAMERA,
	WEAPON,
	DOCUMENT,
	BODY,
	DRUG_PACKAGE
}

@export var evidence_type: EvidenceType = EvidenceType.BLOOD_STAIN
@export var objective_id: String = "clean_blood"
@export var clean_time: float = 5.0  # seconds to clean
@export var requires_tool: String = ""  # tool needed, empty = any
@export var weight: float = 0.0  # for carryable items

var is_cleaned: bool = false
var is_being_cleaned: bool = false
var clean_progress: float = 0.0
var cleaning_player = null

func _ready():
	add_to_group("evidence")

func _process(delta: float):
	if is_being_cleaned and cleaning_player:
		var speed_mod = 1.0
		# Cleaner role bonus
		if cleaning_player.player_role == GameManager.PlayerRole.CLEANER:
			speed_mod = cleaning_player.get_clean_speed()
		
		clean_progress += delta * speed_mod
		emit_signal("cleaning_progress", clean_progress / clean_time)
		
		if clean_progress >= clean_time:
			_complete_clean()

func get_interact_label() -> String:
	if is_cleaned:
		return ""
	match evidence_type:
		EvidenceType.BLOOD_STAIN: return "[E] Limpiar sangre"
		EvidenceType.CAMERA: return "[E] Hackear cámara"
		EvidenceType.WEAPON: return "[E] Recoger arma"
		EvidenceType.DOCUMENT: return "[E] Destruir documento"
		EvidenceType.BODY: return "[E] Mover cuerpo"
		EvidenceType.DRUG_PACKAGE: return "[E] Recoger paquete"
	return "[E] Interactuar"

func interact(player):
	if is_cleaned:
		return
	
	if requires_tool != "" and not _player_has_tool(player, requires_tool):
		print("[Evidence] Necesitas: ", requires_tool)
		return
	
	match evidence_type:
		EvidenceType.BLOOD_STAIN, EvidenceType.CAMERA, EvidenceType.DOCUMENT:
			_start_cleaning(player)
		EvidenceType.WEAPON, EvidenceType.DRUG_PACKAGE:
			_pickup_item(player)
		EvidenceType.BODY:
			_carry_body(player)

func _start_cleaning(player):
	if not is_being_cleaned:
		is_being_cleaned = true
		cleaning_player = player
		print("[Evidence] Cleaning started: ", name)

func stop_cleaning():
	is_being_cleaned = false
	cleaning_player = null

func _complete_clean():
	is_cleaned = true
	is_being_cleaned = false
	cleaning_player = null
	GameManager.complete_objective(objective_id)
	emit_signal("evidence_cleaned", self)
	_play_clean_effect()
	print("[Evidence] Cleaned: ", name)

func _pickup_item(player):
	GameManager.complete_objective(objective_id)
	emit_signal("evidence_cleaned", self)
	_play_clean_effect()
	queue_free()

func _carry_body(player):
	if player.pick_up_object(get_parent() as RigidBody3D, weight):
		GameManager.complete_objective(objective_id)
		emit_signal("evidence_cleaned", self)

func _play_clean_effect():
	# Visual feedback - hide or fade
	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.5)
	tween.tween_callback(queue_free)

func _player_has_tool(player, tool_name: String) -> bool:
	# TODO: integrate with tool inventory
	return true
