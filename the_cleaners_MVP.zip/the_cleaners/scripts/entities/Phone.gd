extends Node3D

# THE CLEANERS - Phone Prop (Safehouse)
# Player interacts with this to answer the call

var is_ringing: bool = false
var safehouse_manager = null

func _ready():
	safehouse_manager = get_tree().get_first_node_in_group("safehouse_manager")
	if not safehouse_manager:
		safehouse_manager = get_parent()

func set_interactable(state: bool):
	is_ringing = state

func get_interact_label() -> String:
	if is_ringing:
		return "[E] Contestar llamada"
	return ""

func interact(player):
	if is_ringing and safehouse_manager and safehouse_manager.has_method("answer_call"):
		safehouse_manager.answer_call()
		is_ringing = false
