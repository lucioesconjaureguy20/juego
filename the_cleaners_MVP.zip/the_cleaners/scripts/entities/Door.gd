extends Node3D

# THE CLEANERS - Interactive Door System

@export var is_locked: bool = false
@export var requires_key: String = ""
@export var open_angle: float = 90.0
@export var open_speed: float = 3.0

var is_open: bool = false
var is_animating: bool = false
var target_rotation: float = 0.0
var start_rotation: float = 0.0
var anim_progress: float = 0.0

@onready var hinge: Node3D = $Hinge
@onready var door_mesh: MeshInstance3D = $Hinge/DoorMesh
@onready var door_sound: AudioStreamPlayer3D = $DoorSound
@onready var collision_open: CollisionShape3D = $CollisionOpen if has_node("CollisionOpen") else null

func _ready():
	add_to_group("doors")

func _process(delta: float):
	if is_animating:
		anim_progress += delta * open_speed
		var t = ease(min(anim_progress, 1.0), -2.0)  # ease in-out
		hinge.rotation.y = lerp(start_rotation, deg_to_rad(target_rotation), t)
		if anim_progress >= 1.0:
			is_animating = false
			anim_progress = 0.0

func get_interact_label() -> String:
	if is_locked:
		return "[E] Puerta cerrada" + (" - Necesitas: " + requires_key if requires_key != "" else "")
	return "[E] " + ("Cerrar puerta" if is_open else "Abrir puerta")

func interact(player):
	if is_locked:
		_play_locked_sound()
		return
	
	_toggle_door(player)

func _toggle_door(player = null):
	is_open = !is_open
	start_rotation = hinge.rotation.y
	
	if is_open:
		# Check which side the player is on to open correctly
		if player:
			var door_to_player = player.global_position - global_position
			var door_forward = -global_transform.basis.z
			if door_to_player.dot(door_forward) < 0:
				target_rotation = open_angle
			else:
				target_rotation = -open_angle
		else:
			target_rotation = open_angle
	else:
		target_rotation = 0.0
	
	is_animating = true
	anim_progress = 0.0
	_play_door_sound()

func _play_door_sound():
	# Will play assigned audio stream
	pass

func _play_locked_sound():
	pass

func unlock(key: String = ""):
	if requires_key == "" or key == requires_key:
		is_locked = false
		return true
	return false
