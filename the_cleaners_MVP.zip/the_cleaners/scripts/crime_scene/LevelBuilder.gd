extends Node3D

# THE CLEANERS - Level Builder
# Constructs the crime scene house programmatically with rooms, walls, doors, furniture, evidence
# This runs at scene load and builds the complete playable environment

const WALL_H = 3.0
const WALL_T = 0.2

# Materials (we'll use solid colors for MVP, replace with textures later)
var mat_floor: StandardMaterial3D
var mat_wall: StandardMaterial3D
var mat_ceiling: StandardMaterial3D
var mat_wood: StandardMaterial3D
var mat_blood: StandardMaterial3D
var mat_dark: StandardMaterial3D

func _ready():
	_create_materials()
	_build_house()
	_place_evidence()
	_place_furniture()
	print("[LevelBuilder] Level constructed successfully")

func _create_materials():
	mat_floor = StandardMaterial3D.new()
	mat_floor.albedo_color = Color(0.55, 0.45, 0.35)  # Wood floor
	
	mat_wall = StandardMaterial3D.new()
	mat_wall.albedo_color = Color(0.85, 0.82, 0.78)  # Off-white walls
	
	mat_ceiling = StandardMaterial3D.new()
	mat_ceiling.albedo_color = Color(0.9, 0.9, 0.9)
	
	mat_wood = StandardMaterial3D.new()
	mat_wood.albedo_color = Color(0.4, 0.25, 0.15)
	
	mat_blood = StandardMaterial3D.new()
	mat_blood.albedo_color = Color(0.6, 0.0, 0.0)
	mat_blood.roughness = 0.8
	
	mat_dark = StandardMaterial3D.new()
	mat_dark.albedo_color = Color(0.15, 0.12, 0.1)

func _build_house():
	# House layout:
	# [Living Room (6x8)] [Kitchen (5x5)]
	# [Hallway (2x8)     ]
	# [Bedroom (5x5)] [Bathroom (4x4)]
	
	var house = get_parent().get_node("House")
	
	# === FLOORS ===
	_make_box(house, "FloorLiving", Vector3(0, 0, 0), Vector3(6, 0.1, 8), mat_floor)
	_make_box(house, "FloorKitchen", Vector3(7, 0, 0), Vector3(5, 0.1, 5), mat_floor)
	_make_box(house, "FloorHall", Vector3(0, 0, 9), Vector3(2, 0.1, 8), mat_floor)
	_make_box(house, "FloorBedroom", Vector3(-4, 0, 9), Vector3(5, 0.1, 5), mat_floor)
	_make_box(house, "FloorBath", Vector3(3, 0, 10), Vector3(4, 0.1, 4), mat_floor)
	
	# === CEILINGS ===
	_make_box(house, "CeilLiving", Vector3(0, WALL_H, 0), Vector3(6, 0.1, 8), mat_ceiling)
	_make_box(house, "CeilKitchen", Vector3(7, WALL_H, 0), Vector3(5, 0.1, 5), mat_ceiling)
	_make_box(house, "CeilHall", Vector3(0, WALL_H, 9), Vector3(2, 0.1, 8), mat_ceiling)
	_make_box(house, "CeilBedroom", Vector3(-4, WALL_H, 9), Vector3(5, 0.1, 5), mat_ceiling)
	_make_box(house, "CeilBath", Vector3(3, WALL_H, 10), Vector3(4, 0.1, 4), mat_ceiling)
	
	# === OUTER WALLS ===
	# Living room outer walls
	_make_wall(house, "WallLivN", Vector3(0, WALL_H/2, -4), Vector3(6, WALL_H, WALL_T))
	_make_wall(house, "WallLivS", Vector3(0, WALL_H/2, 4), Vector3(6, WALL_H, WALL_T))
	_make_wall(house, "WallLivW", Vector3(-3, WALL_H/2, 0), Vector3(WALL_T, WALL_H, 8))
	
	# Kitchen outer walls
	_make_wall(house, "WallKitN", Vector3(7, WALL_H/2, -2.5), Vector3(5, WALL_H, WALL_T))
	_make_wall(house, "WallKitE", Vector3(9.5, WALL_H/2, 0), Vector3(WALL_T, WALL_H, 5))
	_make_wall(house, "WallKitS", Vector3(7, WALL_H/2, 2.5), Vector3(5, WALL_H, WALL_T))
	
	# Hallway
	_make_wall(house, "WallHallW", Vector3(-1, WALL_H/2, 9), Vector3(WALL_T, WALL_H, 8))
	_make_wall(house, "WallHallE", Vector3(1, WALL_H/2, 9), Vector3(WALL_T, WALL_H, 8))
	
	# Bedroom
	_make_wall(house, "WallBedW", Vector3(-6.5, WALL_H/2, 9), Vector3(WALL_T, WALL_H, 5))
	_make_wall(house, "WallBedN", Vector3(-4, WALL_H/2, 6.5), Vector3(5, WALL_H, WALL_T))
	_make_wall(house, "WallBedS", Vector3(-4, WALL_H/2, 11.5), Vector3(5, WALL_H, WALL_T))
	
	# Bathroom
	_make_wall(house, "WallBathE", Vector3(5, WALL_H/2, 10), Vector3(WALL_T, WALL_H, 4))
	_make_wall(house, "WallBathS", Vector3(3, WALL_H/2, 12), Vector3(4, WALL_H, WALL_T))
	_make_wall(house, "WallBathN", Vector3(3, WALL_H/2, 8), Vector3(4, WALL_H, WALL_T))
	
	# === INTERIOR WALLS WITH DOOR GAPS ===
	# Wall between living and kitchen (with door gap at center)
	_make_wall(house, "WallLivKitTop", Vector3(3.5, WALL_H/2, -1.5), Vector3(WALL_T, WALL_H, 5))
	_make_wall(house, "WallLivKitBot", Vector3(3.5, WALL_H/2, 2.5), Vector3(WALL_T, WALL_H, 3))
	# Door gap at z=0 to z=1
	
	# Wall between living and hallway
	_make_wall(house, "WallLivHallW", Vector3(-1, WALL_H/2, 5), Vector3(2, WALL_H, WALL_T))
	_make_wall(house, "WallLivHallE", Vector3(2, WALL_H/2, 5), Vector3(4, WALL_H, WALL_T))
	# Door gap at x=0 to x=1
	
	# Wall between hallway and bedroom
	_make_wall(house, "WallHallBedTop", Vector3(-1.5, WALL_H/2, 7.5), Vector3(3, WALL_H, WALL_T))
	# Door gap
	
	# === DOORS ===
	_spawn_door(house, "DoorKitchen", Vector3(3.5, 0, 0.5), 0.0)
	_spawn_door(house, "DoorHall", Vector3(0.5, 0, 5), 90.0)
	_spawn_door(house, "DoorBedroom", Vector3(-2, 0, 7.5), 0.0)
	_spawn_door(house, "DoorBath", Vector3(3, 0, 9.5), 90.0)
	_spawn_door(house, "DoorEntry", Vector3(-3, 0, 4), 90.0, false)  # Front door, unlocked
	
	# === LIGHTS ===
	_add_room_light(house, "LightLiving", Vector3(0, WALL_H - 0.3, 0), 12.0, Color(1.0, 0.9, 0.75))
	_add_room_light(house, "LightKitchen", Vector3(7, WALL_H - 0.3, 0), 8.0, Color(1.0, 0.95, 0.85))
	_add_room_light(house, "LightBedroom", Vector3(-4, WALL_H - 0.3, 9), 8.0, Color(0.7, 0.6, 1.0))  # Eerie purple
	_add_room_light(house, "LightBath", Vector3(3, WALL_H - 0.3, 10), 5.0, Color(0.9, 0.9, 1.0))
	_add_room_light(house, "LightHall", Vector3(0, WALL_H - 0.3, 9), 5.0, Color(0.8, 0.75, 0.7))

func _make_box(parent: Node3D, name: String, pos: Vector3, size: Vector3, mat: StandardMaterial3D, is_static: bool = true):
	var body = StaticBody3D.new() if is_static else RigidBody3D.new()
	body.name = name
	body.position = pos + Vector3(0, size.y / 2, 0) if pos.y == 0 and size.y < 1 else pos
	
	var mesh_inst = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = size
	mesh_inst.mesh = box
	mesh_inst.material_override = mat
	
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	col.shape = shape
	
	body.add_child(mesh_inst)
	body.add_child(col)
	parent.add_child(body)
	return body

func _make_wall(parent: Node3D, name: String, pos: Vector3, size: Vector3):
	_make_box(parent, name, pos, size, mat_wall)

func _spawn_door(parent: Node3D, door_name: String, pos: Vector3, y_rot_deg: float, locked: bool = false):
	var door_root = Node3D.new()
	door_root.name = door_name
	door_root.position = pos
	door_root.rotation.y = deg_to_rad(y_rot_deg)
	
	var script = load("res://scripts/entities/Door.gd")
	door_root.set_script(script)
	door_root.is_locked = locked
	
	var hinge = Node3D.new()
	hinge.name = "Hinge"
	
	var door_mesh = MeshInstance3D.new()
	door_mesh.name = "DoorMesh"
	door_mesh.position = Vector3(0.5, WALL_H/2, 0)  # Pivot at hinge side
	
	var box_mesh = BoxMesh.new()
	box_mesh.size = Vector3(1.0, WALL_H, 0.05)
	door_mesh.mesh = box_mesh
	door_mesh.material_override = mat_wood
	
	var static_body = StaticBody3D.new()
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(1.0, WALL_H, 0.1)
	col.shape = shape
	col.position = Vector3(0.5, WALL_H/2, 0)
	
	static_body.add_child(col)
	hinge.add_child(door_mesh)
	hinge.add_child(static_body)
	door_root.add_child(hinge)
	parent.add_child(door_root)

func _add_room_light(parent: Node3D, light_name: String, pos: Vector3, energy: float, color: Color):
	var light = OmniLight3D.new()
	light.name = light_name
	light.position = pos
	light.light_energy = energy
	light.light_color = color
	light.omni_range = 8.0
	light.shadow_enabled = true
	parent.add_child(light)

func _place_furniture():
	var house = get_parent().get_node("House")
	var furniture_root = Node3D.new()
	furniture_root.name = "Furniture"
	house.add_child(furniture_root)
	
	# === LIVING ROOM ===
	_make_furniture(furniture_root, "Sofa", Vector3(-1.5, 0, -2), Vector3(3, 0.9, 1.2), mat_dark)
	_make_furniture(furniture_root, "CoffeeTable", Vector3(-1.5, 0, -0.5), Vector3(1.5, 0.45, 0.8), mat_wood)
	_make_furniture(furniture_root, "TV", Vector3(-2.5, 0.8, 2.5), Vector3(1.5, 0.8, 0.1), mat_dark)
	_make_furniture(furniture_root, "TVStand", Vector3(-2.5, 0, 2.5), Vector3(1.5, 0.6, 0.4), mat_wood)
	_make_furniture(furniture_root, "Bookshelf", Vector3(2.5, 0, -3), Vector3(0.4, 2.0, 1.5), mat_wood)
	_make_furniture(furniture_root, "ArmChair", Vector3(1.5, 0, -2), Vector3(1.0, 1.0, 1.0), mat_dark)
	
	# === KITCHEN ===
	_make_furniture(furniture_root, "KitCounter", Vector3(7, 0, -2), Vector3(4, 0.9, 0.7), mat_wood)
	_make_furniture(furniture_root, "KitCounter2", Vector3(9, 0, 0), Vector3(0.7, 0.9, 4), mat_wood)
	_make_furniture(furniture_root, "KitTable", Vector3(6, 0, 1.5), Vector3(1.5, 0.75, 1.0), mat_wood)
	_make_furniture(furniture_root, "KitChair1", Vector3(5.3, 0, 1.2), Vector3(0.5, 0.9, 0.5), mat_dark)
	_make_furniture(furniture_root, "KitChair2", Vector3(6.7, 0, 1.2), Vector3(0.5, 0.9, 0.5), mat_dark)
	
	# === BEDROOM ===
	_make_furniture(furniture_root, "Bed", Vector3(-4.5, 0, 9), Vector3(2.5, 0.5, 4.0), mat_dark)
	_make_furniture(furniture_root, "BedPillow", Vector3(-4.5, 0.5, 7.5), Vector3(2.0, 0.2, 0.8), Color(0.9, 0.9, 0.9))
	_make_furniture(furniture_root, "Wardrobe", Vector3(-6, 0, 9), Vector3(0.6, 2.2, 2.0), mat_wood)
	_make_furniture(furniture_root, "Dresser", Vector3(-3, 0, 11), Vector3(1.0, 1.0, 0.5), mat_wood)
	_make_furniture(furniture_root, "Nightstand", Vector3(-3.2, 0, 8), Vector3(0.5, 0.6, 0.5), mat_wood)
	_make_furniture(furniture_root, "Lamp", Vector3(-3.2, 0.6, 8), Vector3(0.15, 0.5, 0.15), Color(0.9, 0.85, 0.7))
	
	# === BATHROOM ===
	_make_furniture(furniture_root, "Bathtub", Vector3(3, 0, 10.5), Vector3(1.8, 0.5, 0.9), Color(0.9, 0.9, 0.9))
	_make_furniture(furniture_root, "Sink", Vector3(4.5, 0.7, 9.5), Vector3(0.6, 0.1, 0.4), Color(0.9, 0.9, 0.9))
	_make_furniture(furniture_root, "Toilet", Vector3(4.5, 0.35, 11.0), Vector3(0.5, 0.7, 0.7), Color(0.9, 0.9, 0.9))
	_make_furniture(furniture_root, "Mirror", Vector3(4.9, 1.4, 9.5), Vector3(0.05, 0.8, 0.6), Color(0.7, 0.85, 1.0))

func _make_furniture(parent: Node3D, fname: String, pos: Vector3, size: Vector3, color):
	var body = StaticBody3D.new()
	body.name = fname
	body.position = pos + Vector3(0, size.y / 2, 0)
	
	var mesh_inst = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = size
	mesh_inst.mesh = box
	
	var mat = StandardMaterial3D.new()
	if color is Color:
		mat.albedo_color = color
	else:
		mat = color
	mesh_inst.material_override = mat
	
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = size
	col.shape = shape
	
	body.add_child(mesh_inst)
	body.add_child(col)
	parent.add_child(body)
	return body

func _place_evidence():
	var house = get_parent().get_node("House")
	var evidence_root = Node3D.new()
	evidence_root.name = "EvidenceItems"
	house.add_child(evidence_root)
	
	# === BLOOD STAINS (5 total) ===
	_spawn_blood(evidence_root, "Blood_Living1", Vector3(-1.5, 0.06, 0.5))
	_spawn_blood(evidence_root, "Blood_Living2", Vector3(0.5, 0.06, -1.0))
	_spawn_blood(evidence_root, "Blood_Kitchen", Vector3(7.0, 0.06, 0.5))
	_spawn_blood(evidence_root, "Blood_Bedroom1", Vector3(-4.5, 0.06, 9.5))
	_spawn_blood(evidence_root, "Blood_Hall", Vector3(0.0, 0.06, 7.0))
	
	# === SECURITY CAMERAS (2 total) ===
	_spawn_camera(evidence_root, "Camera_Living", Vector3(2.5, WALL_H - 0.4, 3.5))
	_spawn_camera(evidence_root, "Camera_Kitchen", Vector3(9.0, WALL_H - 0.4, -2.0))
	
	# === WEAPON (1 total) ===
	_spawn_weapon(evidence_root, "Weapon_Gun", Vector3(-1.0, 0.5, 1.0))
	
	# === DOCUMENTS (3 total) ===
	_spawn_document(evidence_root, "Doc_CoffeeTable", Vector3(-1.5, 0.5, -0.5))
	_spawn_document(evidence_root, "Doc_Kitchen", Vector3(6.5, 0.96, 1.5))
	_spawn_document(evidence_root, "Doc_Bedroom", Vector3(-3.0, 1.06, 11.0))
	
	# === BODY (1 total) - main objective ===
	_spawn_body(evidence_root, "Body_Main", Vector3(0.0, 0.1, 1.5))

func _spawn_blood(parent: Node3D, bname: String, pos: Vector3):
	var blood = Node3D.new()
	blood.name = bname
	blood.position = pos
	
	var script = load("res://scripts/entities/Evidence.gd")
	blood.set_script(script)
	blood.evidence_type = Evidence.EvidenceType.BLOOD_STAIN
	blood.objective_id = "clean_blood"
	blood.clean_time = 5.0
	
	# Visual: flat disc / splat
	var mesh_inst = MeshInstance3D.new()
	var cyl = CylinderMesh.new()
	cyl.top_radius = randf_range(0.3, 0.7)
	cyl.bottom_radius = cyl.top_radius
	cyl.height = 0.02
	mesh_inst.mesh = cyl
	mesh_inst.material_override = mat_blood
	
	# Rotate randomly for variety
	blood.rotation.y = randf() * TAU
	
	# Area for detection
	var area = Area3D.new()
	var col = CollisionShape3D.new()
	var shape = CylinderShape3D.new()
	shape.radius = cyl.top_radius + 0.3
	shape.height = 0.3
	col.shape = shape
	area.add_child(col)
	
	blood.add_child(mesh_inst)
	blood.add_child(area)
	parent.add_child(blood)

func _spawn_camera(parent: Node3D, cname: String, pos: Vector3):
	var cam = Node3D.new()
	cam.name = cname
	cam.position = pos
	
	var script = load("res://scripts/entities/Evidence.gd")
	cam.set_script(script)
	cam.evidence_type = Evidence.EvidenceType.CAMERA
	cam.objective_id = "destroy_cameras"
	cam.clean_time = 8.0  # Takes longer to hack
	
	# Visual: small box
	var mesh_inst = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.15, 0.1, 0.2)
	mesh_inst.mesh = box
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.1, 0.1, 0.1)
	mesh_inst.material_override = mat
	
	# Red LED light
	var led = OmniLight3D.new()
	led.light_color = Color(1, 0, 0)
	led.light_energy = 0.5
	led.omni_range = 1.0
	led.name = "LED"
	
	# Area
	var area = Area3D.new()
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(0.5, 0.5, 0.5)
	col.shape = shape
	area.add_child(col)
	
	cam.add_child(mesh_inst)
	cam.add_child(led)
	cam.add_child(area)
	parent.add_child(cam)

func _spawn_weapon(parent: Node3D, wname: String, pos: Vector3):
	var weapon = RigidBody3D.new()
	weapon.name = wname
	weapon.position = pos
	weapon.mass = 0.8
	
	var script = load("res://scripts/entities/Evidence.gd")
	weapon.set_script(script)
	weapon.evidence_type = Evidence.EvidenceType.WEAPON
	weapon.objective_id = "collect_weapons"
	weapon.clean_time = 0.0
	
	var mesh_inst = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.05, 0.12, 0.25)
	mesh_inst.mesh = box
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.2, 0.2)
	mesh_inst.material_override = mat
	
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(0.1, 0.15, 0.3)
	col.shape = shape
	
	weapon.add_child(mesh_inst)
	weapon.add_child(col)
	parent.add_child(weapon)

func _spawn_document(parent: Node3D, dname: String, pos: Vector3):
	var doc = Node3D.new()
	doc.name = dname
	doc.position = pos
	
	var script = load("res://scripts/entities/Evidence.gd")
	doc.set_script(script)
	doc.evidence_type = Evidence.EvidenceType.DOCUMENT
	doc.objective_id = "shred_documents"
	doc.clean_time = 3.0
	
	var mesh_inst = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.21, 0.01, 0.297)  # A4 paper
	mesh_inst.mesh = box
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.95, 0.92, 0.85)
	mesh_inst.material_override = mat
	
	# Slight random rotation
	doc.rotation.y = randf_range(-0.3, 0.3)
	
	var area = Area3D.new()
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(0.4, 0.3, 0.5)
	col.shape = shape
	area.add_child(col)
	
	doc.add_child(mesh_inst)
	doc.add_child(area)
	parent.add_child(doc)

func _spawn_body(parent: Node3D, bname: String, pos: Vector3):
	var body = RigidBody3D.new()
	body.name = bname
	body.position = pos
	body.mass = 70.0
	body.freeze = true  # Starts frozen, player picks it up
	
	# The evidence component
	var evidence_node = Node3D.new()
	evidence_node.name = "BodyEvidence"
	var script = load("res://scripts/entities/Evidence.gd")
	evidence_node.set_script(script)
	evidence_node.evidence_type = Evidence.EvidenceType.BODY
	evidence_node.objective_id = "remove_body"
	evidence_node.weight = 70.0
	evidence_node.clean_time = 0.0
	
	# Body mesh - simplified human shape
	var torso_mesh = MeshInstance3D.new()
	var torso = BoxMesh.new()
	torso.size = Vector3(0.45, 0.6, 0.25)
	torso_mesh.mesh = torso
	var mat_body = StandardMaterial3D.new()
	mat_body.albedo_color = Color(0.3, 0.25, 0.2)  # Dark clothes
	torso_mesh.material_override = mat_body
	torso_mesh.position = Vector3(0, 0.3, 0)
	
	var head_mesh = MeshInstance3D.new()
	var head_sph = SphereMesh.new()
	head_sph.radius = 0.12
	head_mesh.mesh = head_sph
	var mat_skin = StandardMaterial3D.new()
	mat_skin.albedo_color = Color(0.8, 0.65, 0.55)
	head_mesh.material_override = mat_skin
	head_mesh.position = Vector3(0, 0.7, 0)
	
	var legs_mesh = MeshInstance3D.new()
	var legs = BoxMesh.new()
	legs.size = Vector3(0.4, 0.7, 0.25)
	legs_mesh.mesh = legs
	legs_mesh.material_override = mat_body
	legs_mesh.position = Vector3(0, -0.05, 0)
	
	var col = CollisionShape3D.new()
	var shape = CapsuleShape3D.new()
	shape.radius = 0.25
	shape.height = 1.7
	col.shape = shape
	col.position = Vector3(0, 0.85, 0)
	
	# Body is lying down
	body.rotation.z = PI / 2
	
	body.add_child(torso_mesh)
	body.add_child(head_mesh)
	body.add_child(legs_mesh)
	body.add_child(col)
	body.add_child(evidence_node)
	parent.add_child(body)
	
	# Add blood under body
	_spawn_blood(parent, "Blood_UnderBody", pos + Vector3(0.3, 0, 0.2))
