extends Node3D

# THE CLEANERS - Crime Scene Manager
# Main gameplay: clean evidence before police arrive

@onready var player: CharacterBody3D = $Player
@onready var hud: Control = $HUD
@onready var exit_trigger: Area3D = $ExitTrigger
@onready var ambient_light: DirectionalLight3D = $AmbientLight
@onready var intro_overlay: ColorRect = $UI/IntroOverlay

var evidence_nodes: Array = []
var mission_complete: bool = false

func _ready():
	GameManager.set_phase(GameManager.GamePhase.CRIME_SCENE)
	
	# Connect signals
	GameManager.mission_completed.connect(_on_mission_complete)
	GameManager.mission_failed.connect(_on_mission_failed)
	
	# Scan evidence
	await get_tree().process_frame
	_collect_evidence()
	
	# Start with intro
	_play_intro_sequence()
	
	# Setup exit
	if exit_trigger:
		exit_trigger.body_entered.connect(_on_exit_triggered)
	
	print("[CrimeScene] Ready. Evidence count: ", evidence_nodes.size())

func _collect_evidence():
	evidence_nodes = get_tree().get_nodes_in_group("evidence")
	print("[CrimeScene] Found ", evidence_nodes.size(), " evidence items")

func _play_intro_sequence():
	if intro_overlay:
		intro_overlay.color = Color(0, 0, 0, 1)
		intro_overlay.visible = true
		
		# Fade in
		var tween = create_tween()
		tween.tween_property(intro_overlay, "color:a", 0.0, 2.0)
		tween.tween_callback(func(): intro_overlay.visible = false)
	
	# Start mission after fade
	await get_tree().create_timer(2.0).timeout
	GameManager.start_mission()
	
	# Show mission briefing
	_show_mission_briefing()

func _show_mission_briefing():
	if hud:
		var briefing = hud.get_node_or_null("MissionBriefing")
		if briefing:
			briefing.visible = true
			await get_tree().create_timer(3.0).timeout
			briefing.visible = false

func _on_mission_complete(rating: String):
	mission_complete = true
	print("[CrimeScene] Mission complete! Rating: ", rating)
	
	if hud:
		var complete_panel = hud.get_node_or_null("MissionComplete")
		if complete_panel:
			complete_panel.visible = true
			var rating_label = complete_panel.get_node_or_null("Rating")
			if rating_label:
				rating_label.text = "CALIFICACIÓN: " + rating

func _on_mission_failed(reason: String):
	print("[CrimeScene] Mission failed: ", reason)
	
	if hud:
		var fail_panel = hud.get_node_or_null("MissionFailed")
		if fail_panel:
			fail_panel.visible = true
			var reason_label = fail_panel.get_node_or_null("Reason")
			if reason_label:
				reason_label.text = reason

func _on_exit_triggered(body: Node3D):
	if body == player:
		if mission_complete:
			_exit_mission()
		elif GameManager._all_objectives_complete():
			GameManager.trigger_mission_complete()
		else:
			# Show message: objectives not complete
			print("[CrimeScene] Can't leave: objectives not complete!")

func _exit_mission():
	var overlay = ColorRect.new()
	overlay.color = Color(0, 0, 0, 0)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	$UI.add_child(overlay)
	
	var tween = create_tween()
	tween.tween_property(overlay, "color:a", 1.0, 2.0)
	tween.tween_callback(func(): get_tree().change_scene_to_file("res://scenes/ui/results.tscn"))
