extends Node

# THE CLEANERS - GameManager (Autoload)
# Central singleton that manages game state, mission flow, and player data

signal mission_started()
signal mission_completed(rating: String)
signal mission_failed(reason: String)
signal objective_updated(objective_id: String, completed: bool)
signal phase_changed(new_phase: String)
signal police_timer_updated(time_remaining: float)

enum GamePhase {
	MAIN_MENU,
	SAFEHOUSE,
	TRANSIT,
	CRIME_SCENE,
	ESCAPE,
	RESULTS
}

enum PlayerRole {
	CLEANER,
	HACKER,
	CARRIER,
	LOOKOUT
}

# Current game state
var current_phase: GamePhase = GamePhase.MAIN_MENU
var current_mission: Dictionary = {}
var players: Array = []
var is_multiplayer: bool = false

# Mission state
var objectives: Dictionary = {}
var evidence_remaining: int = 0
var police_timer: float = 0.0
var police_time_max: float = 300.0  # 5 minutes default
var mission_start_time: float = 0.0
var mission_active: bool = false
var police_arrived: bool = false

# Player role assignments
var player_roles: Dictionary = {}

# Stats tracking
var items_cleaned: int = 0
var bodies_moved: int = 0
var cameras_hacked: int = 0
var noise_level: float = 0.0

func _ready():
	print("[GameManager] Initialized")
	_setup_default_mission()

func _process(delta: float):
	if mission_active and current_phase == GamePhase.CRIME_SCENE:
		police_timer -= delta
		emit_signal("police_timer_updated", police_timer)
		
		if police_timer <= 0.0 and not police_arrived:
			_trigger_police_arrival()

func _setup_default_mission():
	current_mission = {
		"name": "Operación Casa Roja",
		"location": "Residencia Suburban",
		"police_time": 300.0,
		"difficulty": "normal",
		"objectives": [
			{"id": "clean_blood", "label": "Limpiar manchas de sangre", "count": 5, "done": 0},
			{"id": "remove_body", "label": "Mover el cuerpo", "count": 1, "done": 0},
			{"id": "destroy_cameras", "label": "Borrar cámaras", "count": 2, "done": 0},
			{"id": "collect_weapons", "label": "Recoger armas", "count": 1, "done": 0},
			{"id": "shred_documents", "label": "Destruir documentos", "count": 3, "done": 0},
		]
	}
	
	for obj in current_mission["objectives"]:
		objectives[obj["id"]] = obj.duplicate()

func start_mission():
	mission_active = true
	police_timer = current_mission.get("police_time", 300.0)
	police_time_max = police_timer
	mission_start_time = Time.get_ticks_msec() / 1000.0
	police_arrived = false
	items_cleaned = 0
	bodies_moved = 0
	cameras_hacked = 0
	noise_level = 0.0
	emit_signal("mission_started")
	print("[GameManager] Mission started: ", current_mission["name"])

func complete_objective(objective_id: String, amount: int = 1):
	if objective_id in objectives:
		var obj = objectives[objective_id]
		obj["done"] = min(obj["done"] + amount, obj["count"])
		emit_signal("objective_updated", objective_id, obj["done"] >= obj["count"])
		
		# Track stats
		match objective_id:
			"clean_blood": items_cleaned += amount
			"remove_body": bodies_moved += amount
			"destroy_cameras": cameras_hacked += amount
		
		# Check evidence remaining
		evidence_remaining = _count_remaining_evidence()
		
		if _all_objectives_complete():
			print("[GameManager] All objectives complete!")

func _count_remaining_evidence() -> int:
	var total = 0
	for obj_id in objectives:
		var obj = objectives[obj_id]
		total += max(0, obj["count"] - obj["done"])
	return total

func _all_objectives_complete() -> bool:
	for obj_id in objectives:
		var obj = objectives[obj_id]
		if obj["done"] < obj["count"]:
			return false
	return true

func trigger_mission_complete():
	mission_active = false
	var rating = _calculate_rating()
	emit_signal("mission_completed", rating)
	print("[GameManager] Mission complete! Rating: ", rating)

func _calculate_rating() -> String:
	var time_elapsed = Time.get_ticks_msec() / 1000.0 - mission_start_time
	var time_ratio = time_elapsed / police_time_max
	var all_done = _all_objectives_complete()
	
	if not all_done:
		return "D"
	elif time_ratio < 0.4 and noise_level < 20.0:
		return "S"
	elif time_ratio < 0.6:
		return "A"
	elif time_ratio < 0.8:
		return "B"
	else:
		return "C"

func _trigger_police_arrival():
	police_arrived = true
	print("[GameManager] POLICE HAS ARRIVED!")
	emit_signal("mission_failed", "La policía llegó antes de que terminaran")

func fail_mission(reason: String):
	mission_active = false
	emit_signal("mission_failed", reason)

func add_noise(amount: float):
	noise_level += amount
	noise_level = clamp(noise_level, 0.0, 100.0)

func set_phase(phase: GamePhase):
	current_phase = phase
	emit_signal("phase_changed", GamePhase.keys()[phase])
	print("[GameManager] Phase: ", GamePhase.keys()[phase])

func get_police_timer_normalized() -> float:
	if police_time_max <= 0:
		return 0.0
	return police_timer / police_time_max

func register_player(player_node, role: PlayerRole):
	players.append(player_node)
	player_roles[player_node] = role
	print("[GameManager] Player registered with role: ", PlayerRole.keys()[role])

func get_role_for_player(player_node) -> PlayerRole:
	return player_roles.get(player_node, PlayerRole.CLEANER)
