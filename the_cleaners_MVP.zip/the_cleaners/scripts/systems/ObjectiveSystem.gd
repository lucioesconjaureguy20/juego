extends Node

# THE CLEANERS - Objective System (Autoload)

signal objectives_changed()
signal all_objectives_complete()

var objectives: Array = []

func _ready():
	if has_node("/root/GameManager"):
		GameManager.objective_updated.connect(_on_objective_updated)

func _on_objective_updated(id: String, completed: bool):
	emit_signal("objectives_changed")
	if _check_all_complete():
		emit_signal("all_objectives_complete")

func _check_all_complete() -> bool:
	for obj in GameManager.objectives.values():
		if obj["done"] < obj["count"]:
			return false
	return true

func get_objectives_display() -> Array:
	var result = []
	for obj_id in GameManager.objectives:
		var obj = GameManager.objectives[obj_id]
		result.append({
			"label": obj["label"],
			"done": obj["done"],
			"count": obj["count"],
			"complete": obj["done"] >= obj["count"]
		})
	return result
