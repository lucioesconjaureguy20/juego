extends Node3D

# THE CLEANERS - Safehouse Scene
# Player starts here, receives the call, boards the van

@onready var player: CharacterBody3D = $Player
@onready var phone: Node3D = $Props/Phone
@onready var van_trigger: Area3D = $VanTrigger
@onready var call_ui: Control = $UI/CallUI
@onready var ambient_player: AudioStreamPlayer = $AmbientPlayer

var call_received: bool = false
var can_board_van: bool = false
var call_timer: float = 8.0  # seconds until phone rings

func _ready():
	GameManager.set_phase(GameManager.GamePhase.SAFEHOUSE)
	
	# Register player
	var role = GameManager.player_roles.get("local_player", GameManager.PlayerRole.CLEANER)
	GameManager.register_player(player, role)
	
	# Start ambient
	_setup_scene()
	
	# Phone will ring after a few seconds
	var timer = get_tree().create_timer(call_timer)
	timer.timeout.connect(_ring_phone)
	
	print("[Safehouse] Scene ready")

func _setup_scene():
	# Setup van entry trigger
	if van_trigger:
		van_trigger.body_entered.connect(_on_van_trigger_entered)

func _ring_phone():
	if call_ui:
		call_ui.visible = true
		# Animate phone UI
		_show_incoming_call()

func _show_incoming_call():
	if not call_ui:
		return
	
	var label = call_ui.get_node_or_null("Label")
	if label:
		label.text = "📞 LLAMADA ENTRANTE\n'Jefe'\n\n[E] Contestar"
	
	# Make phone interactable
	if phone and phone.has_method("set_interactable"):
		phone.set_interactable(true)

func answer_call():
	call_received = true
	can_board_van = true
	
	if call_ui:
		var label = call_ui.get_node_or_null("Label")
		if label:
			label.text = "📞 EN LLAMADA\n\n\"Escúchenme. Tenemos un trabajo.\nResidul Maplewood 42. Hay evidencia\npor todas partes. La policía llega\nen 5 minutos. ¡Muévanse!\"\n\n[Colgar y ir a la van]"
		
		await get_tree().create_timer(4.0).timeout
		
		label.text = "⚠️ MISIÓN RECIBIDA\nOperación Casa Roja\n\nSube a la van para comenzar"
		await get_tree().create_timer(2.0).timeout
		call_ui.visible = false

func _on_van_trigger_entered(body: Node3D):
	if body == player and can_board_van:
		_board_van()

func _board_van():
	print("[Safehouse] Boarding van...")
	GameManager.set_phase(GameManager.GamePhase.TRANSIT)
	
	# Transition to crime scene
	var transition = _create_transition_overlay()
	await get_tree().create_timer(2.5).timeout
	get_tree().change_scene_to_file("res://scenes/crime_scene/crime_scene.tscn")

func _create_transition_overlay() -> ColorRect:
	var overlay = ColorRect.new()
	overlay.color = Color(0, 0, 0, 0)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(overlay)
	
	var tween = create_tween()
	tween.tween_property(overlay, "color:a", 1.0, 1.5)
	return overlay
