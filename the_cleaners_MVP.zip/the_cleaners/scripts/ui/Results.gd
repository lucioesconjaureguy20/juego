extends Control

# THE CLEANERS - Results Screen

@onready var rating_label: Label = $Panel/VBox/Rating
@onready var stats_label: Label = $Panel/VBox/Stats
@onready var btn_retry: Button = $Panel/VBox/BtnRetry
@onready var btn_menu: Button = $Panel/VBox/BtnMenu

func _ready():
	var rating = GameManager._calculate_rating()
	var failed = GameManager.police_arrived
	
	if failed:
		rating_label.text = "MISIÓN FALLIDA"
		rating_label.add_theme_color_override("font_color", Color(1, 0.1, 0.1))
	else:
		rating_label.text = "MISIÓN COMPLETADA\nCalificación: " + rating
		var colors = {"S": Color(1,0.9,0), "A": Color(0.2,1,0.2), "B": Color(0.2,0.6,1), "C": Color(0.8,0.8,0.8), "D": Color(0.5,0.5,0.5)}
		rating_label.add_theme_color_override("font_color", colors.get(rating, Color.WHITE))
	
	stats_label.text = """
Elementos limpiados: %d
Cuerpos movidos: %d
Cámaras borradas: %d
Nivel de ruido final: %d%%
Tiempo: %s
""" % [
		GameManager.items_cleaned,
		GameManager.bodies_moved,
		GameManager.cameras_hacked,
		int(GameManager.noise_level),
		_format_time()
	]
	
	btn_retry.pressed.connect(_retry)
	btn_menu.pressed.connect(_main_menu)

func _format_time() -> String:
	var elapsed = Time.get_ticks_msec() / 1000.0 - GameManager.mission_start_time
	var m = int(elapsed / 60)
	var s = int(fmod(elapsed, 60))
	return "%02d:%02d" % [m, s]

func _retry():
	GameManager._setup_default_mission()
	get_tree().change_scene_to_file("res://scenes/crime_scene/crime_scene.tscn")

func _main_menu():
	get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")
