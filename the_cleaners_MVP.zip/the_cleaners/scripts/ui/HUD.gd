extends Control

# THE CLEANERS - HUD
# Displays timer, objectives, interaction prompt, role, carried item

@onready var timer_label: Label = $TopBar/TimerLabel
@onready var timer_bar: ProgressBar = $TopBar/TimerBar
@onready var role_label: Label = $TopBar/RoleLabel
@onready var objectives_panel: VBoxContainer = $LeftPanel/ObjectivesVBox
@onready var interact_prompt: Label = $InteractPrompt
@onready var cleaning_bar: ProgressBar = $CleaningProgress
@onready var carry_label: Label = $BottomBar/CarryLabel
@onready var noise_bar: ProgressBar = $BottomBar/NoiseBar
@onready var mission_briefing: PanelContainer = $MissionBriefing
@onready var mission_complete: PanelContainer = $MissionComplete
@onready var mission_failed: PanelContainer = $MissionFailed
@onready var alert_label: Label = $AlertLabel

var player_ref = null
var last_noise: float = 0.0

func _ready():
	# Connect to GameManager
	GameManager.police_timer_updated.connect(_on_timer_updated)
	GameManager.objective_updated.connect(_on_objective_updated)
	GameManager.mission_started.connect(_on_mission_started)
	
	interact_prompt.visible = false
	cleaning_bar.visible = false
	mission_complete.visible = false
	mission_failed.visible = false
	
	_build_objectives_list()
	
	# Find player
	await get_tree().process_frame
	player_ref = get_tree().get_first_node_in_group("players")
	if player_ref:
		role_label.text = "ROL: " + player_ref.get_role_label()
		player_ref.interactable_found.connect(_on_interactable_found)
		player_ref.interactable_lost.connect(_on_interactable_lost)

func _process(delta: float):
	_update_noise_display()
	_update_carry_display()

func _on_timer_updated(time_remaining: float):
	var minutes = int(time_remaining / 60)
	var seconds = int(fmod(time_remaining, 60))
	timer_label.text = "⏱ %02d:%02d" % [minutes, seconds]
	
	var normalized = GameManager.get_police_timer_normalized()
	timer_bar.value = normalized * 100
	
	# Color change based on urgency
	if normalized < 0.25:
		timer_label.add_theme_color_override("font_color", Color(1, 0.2, 0.2))
		timer_bar.add_theme_color_override("fill", Color(1, 0.1, 0.1))
		# Flash effect
		timer_label.modulate.a = 0.5 + sin(Time.get_ticks_msec() * 0.01) * 0.5
	elif normalized < 0.5:
		timer_label.add_theme_color_override("font_color", Color(1, 0.8, 0.0))
		timer_label.modulate.a = 1.0

func _on_mission_started():
	_build_objectives_list()
	alert_label.text = "¡MISIÓN INICIADA! Limpia toda la evidencia."
	alert_label.visible = true
	var tween = create_tween()
	tween.tween_interval(3.0)
	tween.tween_property(alert_label, "modulate:a", 0.0, 1.0)
	tween.tween_callback(func(): alert_label.visible = false; alert_label.modulate.a = 1.0)

func _build_objectives_list():
	for child in objectives_panel.get_children():
		child.queue_free()
	
	var title = Label.new()
	title.text = "📋 OBJETIVOS"
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	objectives_panel.add_child(title)
	
	for obj_data in GameManager.objectives.values():
		var row = HBoxContainer.new()
		
		var check = Label.new()
		check.text = "✓ " if obj_data["done"] >= obj_data["count"] else "○ "
		check.add_theme_color_override("font_color", Color(0.2, 1.0, 0.2) if obj_data["done"] >= obj_data["count"] else Color(0.7, 0.7, 0.7))
		check.add_theme_font_size_override("font_size", 14)
		check.name = "check_" + obj_data["id"] if obj_data.has("id") else "check"
		
		var label = Label.new()
		label.text = obj_data["label"] + " (%d/%d)" % [obj_data["done"], obj_data["count"]]
		label.add_theme_font_size_override("font_size", 14)
		label.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5) if obj_data["done"] >= obj_data["count"] else Color(0.9, 0.9, 0.9))
		label.name = "label_" + (obj_data["id"] if obj_data.has("id") else "obj")
		
		row.add_child(check)
		row.add_child(label)
		row.name = "obj_row_" + (obj_data["id"] if obj_data.has("id") else "row")
		objectives_panel.add_child(row)

func _on_objective_updated(id: String, completed: bool):
	_build_objectives_list()
	
	# Flash green for completed
	if completed:
		alert_label.text = "✓ Objetivo completado!"
		alert_label.add_theme_color_override("font_color", Color(0.2, 1.0, 0.2))
		alert_label.modulate.a = 1.0
		alert_label.visible = true
		var tween = create_tween()
		tween.tween_interval(2.0)
		tween.tween_property(alert_label, "modulate:a", 0.0, 0.5)
		tween.tween_callback(func():
			alert_label.visible = false
			alert_label.modulate.a = 1.0
			alert_label.remove_theme_color_override("font_color")
		)

func _on_interactable_found(node: Node, label: String):
	interact_prompt.text = label
	interact_prompt.visible = true
	
	# Check if cleanable
	if node is Evidence and (node.evidence_type == Evidence.EvidenceType.BLOOD_STAIN or 
		node.evidence_type == Evidence.EvidenceType.CAMERA or
		node.evidence_type == Evidence.EvidenceType.DOCUMENT):
		cleaning_bar.visible = true
		if node.has_signal("cleaning_progress"):
			node.cleaning_progress.connect(_on_cleaning_progress)

func _on_interactable_lost():
	interact_prompt.visible = false
	cleaning_bar.visible = false
	cleaning_bar.value = 0

func _on_cleaning_progress(percent: float):
	cleaning_bar.value = percent * 100

func _update_noise_display():
	if noise_bar:
		noise_bar.value = GameManager.noise_level
		if GameManager.noise_level > 70:
			noise_bar.add_theme_color_override("fill", Color(1, 0, 0))
		elif GameManager.noise_level > 40:
			noise_bar.add_theme_color_override("fill", Color(1, 0.8, 0))
		else:
			noise_bar.add_theme_color_override("fill", Color(0.2, 0.8, 0.2))

func _update_carry_display():
	if carry_label and player_ref:
		if player_ref.is_carrying:
			carry_label.text = "Cargando: " + str(player_ref.carried_weight) + "kg"
			carry_label.visible = true
		else:
			carry_label.visible = false

func show_alert(message: String, color: Color = Color.WHITE):
	alert_label.text = message
	alert_label.add_theme_color_override("font_color", color)
	alert_label.modulate.a = 1.0
	alert_label.visible = true
	var tween = create_tween()
	tween.tween_interval(3.0)
	tween.tween_property(alert_label, "modulate:a", 0.0, 1.0)
	tween.tween_callback(func(): alert_label.visible = false; alert_label.modulate.a = 1.0)
