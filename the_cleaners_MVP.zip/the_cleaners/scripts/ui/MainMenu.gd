extends Control

# THE CLEANERS - Main Menu

@onready var btn_solo: Button = $CenterContainer/BtnSolo
@onready var btn_roles: Button = $CenterContainer/BtnRoles
@onready var btn_quit: Button = $CenterContainer/BtnQuit
@onready var role_selector: PanelContainer = $RoleSelector

var selected_role: GameManager.PlayerRole = GameManager.PlayerRole.CLEANER

func _ready():
	btn_solo.pressed.connect(_on_solo_pressed)
	btn_roles.pressed.connect(_on_roles_pressed)
	btn_quit.pressed.connect(_on_quit_pressed)
	
	# Style buttons
	_style_menu()

func _style_menu():
	for btn in [btn_solo, btn_roles, btn_quit]:
		btn.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
		btn.add_theme_color_override("font_hover_color", Color(1.0, 0.2, 0.2))

func _on_solo_pressed():
	# Set default role and go to safehouse
	GameManager.player_roles = {}
	GameManager.set_phase(GameManager.GamePhase.SAFEHOUSE)
	get_tree().change_scene_to_file("res://scenes/safehouse/safehouse.tscn")

func _on_roles_pressed():
	_show_role_selector()

func _on_quit_pressed():
	get_tree().quit()

func _show_role_selector():
	role_selector.visible = true
	# Populate roles dynamically
	var role_grid = role_selector.get_node("RoleVBox/RoleGrid")
	for child in role_grid.get_children():
		child.queue_free()
	
	var roles = [
		{"id": GameManager.PlayerRole.CLEANER, "name": "LIMPIADOR", "desc": "Limpia sangre 2x más rápido.\nHerramienta: Trapo y balde."},
		{"id": GameManager.PlayerRole.HACKER, "name": "HACKER", "desc": "Hackea cámaras y alarmas.\nMás silencioso."},
		{"id": GameManager.PlayerRole.CARRIER, "name": "CARGADOR", "desc": "Mueve cuerpos pesados.\nDoble capacidad de carga."},
		{"id": GameManager.PlayerRole.LOOKOUT, "name": "VIGILANTE", "desc": "Detecta peligros.\nMás rápido y silencioso."},
	]
	
	for role_data in roles:
		var panel = PanelContainer.new()
		panel.custom_minimum_size = Vector2(350, 180)
		
		var vbox = VBoxContainer.new()
		
		var name_label = Label.new()
		name_label.text = role_data["name"]
		name_label.add_theme_font_size_override("font_size", 24)
		name_label.add_theme_color_override("font_color", Color(0.9, 0.2, 0.2))
		
		var desc_label = Label.new()
		desc_label.text = role_data["desc"]
		desc_label.add_theme_font_size_override("font_size", 16)
		desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD
		
		var btn = Button.new()
		btn.text = "SELECCIONAR"
		btn.add_theme_font_size_override("font_size", 18)
		var rid = role_data["id"]
		btn.pressed.connect(func(): _select_role(rid))
		
		vbox.add_child(name_label)
		vbox.add_child(desc_label)
		vbox.add_child(btn)
		panel.add_child(vbox)
		role_grid.add_child(panel)
	
	var close_btn = Button.new()
	close_btn.text = "VOLVER"
	close_btn.pressed.connect(func(): role_selector.visible = false)
	role_selector.get_node("RoleVBox").add_child(close_btn)

func _select_role(role: GameManager.PlayerRole):
	selected_role = role
	role_selector.visible = false
	_on_solo_pressed()
