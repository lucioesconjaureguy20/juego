extends Control

# THE CLEANERS - Pause Menu

@onready var btn_resume: Button = $Panel/VBox/BtnResume
@onready var btn_menu: Button = $Panel/VBox/BtnMenu
@onready var btn_quit: Button = $Panel/VBox/BtnQuit

func _ready():
	btn_resume.pressed.connect(_resume)
	btn_menu.pressed.connect(_main_menu)
	btn_quit.pressed.connect(_quit)

func _resume():
	get_tree().paused = false
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	visible = false

func _main_menu():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")

func _quit():
	get_tree().quit()
